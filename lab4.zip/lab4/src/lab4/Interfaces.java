package lab4;

public interface Interfaces {
	

}

interface iPrint{
	void mPrint();
}

interface iPrintText{
	void mPrintText(String t);
}

interface iIsEven{
	boolean mIsEven(int x);
}

interface iSum{
	double mSum(double a, double b);
}

interface iMax{
	int mMax(int []tab);
}

interface iGen<R,P>{ //R - result, P - parameter
	R metoda (P param1, P param2);
}
