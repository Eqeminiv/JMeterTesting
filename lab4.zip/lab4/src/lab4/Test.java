package lab4;

public class Test {
	
	public void print(){ //()->System.out.println("Test");
		System.out.println("Test");
	}
	
	public void printText(String text){ // t -> System.out.println(t);
		System.out.println(text);
	}
	
	public boolean isEven(int x){ // x -> x%2==0;
		return x%2 == 0;
	}
	
	public double sum(double a, double b){ // (a,b) -> a+b;
		return a+b;
	}
	
	public int getNumber(){ // () -> 1;
		return 1;
	}
	
	public int max(int[] tab){ 
		int m = tab[0];
		
		for(int i=1;i<tab.length;i++)
		{
			if(m<tab[i])
				m = tab[i];
		}
		return m;
	}
	
	//^
	/* tab -> { *kod wyzej od int m* }*/

	
	public static void foo(iGen<Integer, String> i, String p1, String p2){
		System.out.println(i.metoda(p1, p2));
	}
}
