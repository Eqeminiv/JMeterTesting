package lab4;

import java.util.GregorianCalendar;
import java.util.Properties;
import java.util.function.Function;
import java.util.function.Supplier;

public class Main {

	public static void main(String[] args) {
		iPrint i1 = () -> System.out.println("Test");
		i1.mPrint();
		
		iPrintText i2 = t -> System.out.println(t);
		i2.mPrintText("Wow");
		
		iIsEven i3 = x -> x%2==0;
		System.out.println(i3.mIsEven(4));
		
		/*iSum i4 = (a,b) -> a+b;
		System.out.print(i4.mSum(3, 4));*/
		
		iGen<Double,Double> i4 = (a,b) -> a+b;
		System.out.println(i4.metoda(200.0,12.0));
		
		iMax i5 = tab ->
		{
			int m = tab[0];
			
			for(int i=1;i<tab.length;i++)
			{
				if(m<tab[i])
					m = tab[i];
			}
			return m;
		};
		
		Test.foo((p,q) -> p.length() + q.length(), "Ala", "ma kota");
		
		Function<Byte,Long> r1 = x -> 1000*(long)x;
		System.out.println(r1.apply((byte)2));
		
		Supplier<Properties> r2 = () -> System.getProperties();
		System.out.println(r2.get());
		
		
		
		
	}

}
